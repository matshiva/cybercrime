function checkAnswers(event) {
    event.preventDefault();
    let correctAnswers = ['b', 'a', 'a', 'b', 'a'];
    let userAnswers = [];
    
    userAnswers.push(document.querySelector('input[name="question1"]:checked').value);
    userAnswers.push(document.querySelector('input[name="question2"]:checked').value);
    userAnswers.push(document.querySelector('input[name="question3"]:checked').value);
    userAnswers.push(document.querySelector('input[name="question4"]:checked').value);
    userAnswers.push(Array.from(document.querySelectorAll('input[name="question5"]:checked')).map(el => el.value));

    let score = 0;
    let correct = [];
    let incorrect = [];
    for (let i = 0; i < correctAnswers.length; i++) {
        if (Array.isArray(userAnswers[i])) {
            if (userAnswers[i].length === 2 && userAnswers[i].includes('a') && userAnswers[i].includes('b')) {
                score++;
                correct.push(i + 1);
            } else {
                incorrect.push(i + 1);
            }
        } else if (userAnswers[i] === correctAnswers[i]) {
            score++;
            correct.push(i + 1);
        } else {
            incorrect.push(i + 1);
        }
    }

    document.getElementById('result').innerHTML = `Правильные ответы: ${correct.join(', ')}.<br> Неправильные ответы: ${incorrect.join(', ')}.<br> Количество правильных ответов: ${score}/5`;
}
